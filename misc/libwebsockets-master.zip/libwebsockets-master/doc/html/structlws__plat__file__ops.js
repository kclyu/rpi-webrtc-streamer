var structlws__plat__file__ops =
[
    [ "close", "structlws__plat__file__ops.html#a034ec96f2fbaf52b4aa3e82d20795f7b", null ],
    [ "open", "structlws__plat__file__ops.html#ad37a97abc68d0af967cef874f4d8df32", null ],
    [ "read", "structlws__plat__file__ops.html#a01f483807a9862736b17ba9ed5110c40", null ],
    [ "seek_cur", "structlws__plat__file__ops.html#abfcda19b003dcc13c61ff9e2bb4ff869", null ],
    [ "write", "structlws__plat__file__ops.html#a1fae8330ee94649a3551e31a30809793", null ]
];