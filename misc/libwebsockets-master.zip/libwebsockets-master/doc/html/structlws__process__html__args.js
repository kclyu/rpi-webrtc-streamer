var structlws__process__html__args =
[
    [ "final", "structlws__process__html__args.html#a362547891ee0d693f3900a1f807ea475", null ],
    [ "len", "structlws__process__html__args.html#a754513f2311241cabb0cd1c90d7307ef", null ],
    [ "max_len", "structlws__process__html__args.html#a8be7fd396a1942ea2449a2fda990ff99", null ],
    [ "p", "structlws__process__html__args.html#a11859d8bedd379fbf64543b25c65fe14", null ]
];