var group__sending_data =
[
    [ "lws_write_protocol", "group__sending-data.html#ga98b099cf8c1c7e38ad78501f270e193d", [
      [ "LWS_WRITE_TEXT", "group__sending-data.html#gga98b099cf8c1c7e38ad78501f270e193da80e8f169fda236c56bfb795ed62903db", null ],
      [ "LWS_WRITE_BINARY", "group__sending-data.html#gga98b099cf8c1c7e38ad78501f270e193daf6486c0dba50c44198100717721d9ab2", null ],
      [ "LWS_WRITE_CONTINUATION", "group__sending-data.html#gga98b099cf8c1c7e38ad78501f270e193da10047eb05b5e1c298151dc47a5b44826", null ],
      [ "LWS_WRITE_HTTP", "group__sending-data.html#gga98b099cf8c1c7e38ad78501f270e193dabb6705e1d1327cdda5025be28f07712e", null ],
      [ "LWS_WRITE_HTTP_HEADERS", "group__sending-data.html#gga98b099cf8c1c7e38ad78501f270e193dafe5a38e940ce56708ac814627e9c0917", null ],
      [ "LWS_WRITE_NO_FIN", "group__sending-data.html#gga98b099cf8c1c7e38ad78501f270e193da115440f272a5d55518adfc8099acfee3", null ],
      [ "LWS_WRITE_CLIENT_IGNORE_XOR_MASK", "group__sending-data.html#gga98b099cf8c1c7e38ad78501f270e193da220d8e8652d9b97fb66e476e2a60ffce", null ]
    ] ],
    [ "lws_write", "group__sending-data.html#gafd5fdd285a0e25ba7e3e1051deec1001", null ]
];