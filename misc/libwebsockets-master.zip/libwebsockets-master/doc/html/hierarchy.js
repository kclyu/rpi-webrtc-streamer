var hierarchy =
[
    [ "lws_cgi_args", "structlws__cgi__args.html", null ],
    [ "lws_client_connect_info", "structlws__client__connect__info.html", null ],
    [ "lws_conn", "classlws__conn.html", [
      [ "lws_conn_listener", "classlws__conn__listener.html", null ]
    ] ],
    [ "lws_context_creation_info", "structlws__context__creation__info.html", null ],
    [ "lws_email", "structlws__email.html", null ],
    [ "lws_ext_option_arg", "structlws__ext__option__arg.html", null ],
    [ "lws_ext_options", "structlws__ext__options.html", null ],
    [ "lws_extension", "structlws__extension.html", null ],
    [ "lws_gs_event_args", "structlws__gs__event__args.html", null ],
    [ "lws_http_mount", "structlws__http__mount.html", null ],
    [ "lws_plat_file_ops", "structlws__plat__file__ops.html", null ],
    [ "lws_plugin", "structlws__plugin.html", null ],
    [ "lws_plugin_capability", "structlws__plugin__capability.html", null ],
    [ "lws_polarssl_context", "structlws__polarssl__context.html", null ],
    [ "lws_pollargs", "structlws__pollargs.html", null ],
    [ "lws_pollfd", "structlws__pollfd.html", null ],
    [ "lws_process_html_args", "structlws__process__html__args.html", null ],
    [ "lws_process_html_state", "structlws__process__html__state.html", null ],
    [ "lws_protocol_vhost_options", "structlws__protocol__vhost__options.html", null ],
    [ "lws_protocols", "structlws__protocols.html", null ],
    [ "lws_session_info", "structlws__session__info.html", null ],
    [ "lws_token_limits", "structlws__token__limits.html", null ],
    [ "lws_tokens", "structlws__tokens.html", null ],
    [ "lwsgw_hash", "structlwsgw__hash.html", null ],
    [ "lwsgw_hash_bin", "structlwsgw__hash__bin.html", null ],
    [ "pollfd", "structpollfd.html", null ]
];