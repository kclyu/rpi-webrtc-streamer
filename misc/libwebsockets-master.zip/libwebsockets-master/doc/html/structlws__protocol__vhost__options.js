var structlws__protocol__vhost__options =
[
    [ "name", "structlws__protocol__vhost__options.html#acf9db77f8eb64cd4e314be9b43d8a8b9", null ],
    [ "next", "structlws__protocol__vhost__options.html#abc714ddb4171756fc8196e9823a1e21c", null ],
    [ "options", "structlws__protocol__vhost__options.html#afd99fbc90be51ea2465b550c2ec47822", null ],
    [ "value", "structlws__protocol__vhost__options.html#a0640a92513c70ee6b9b295a9ad1658e7", null ]
];