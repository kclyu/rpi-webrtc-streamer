var structlws__process__html__state =
[
    [ "count_vars", "structlws__process__html__state.html#adcafd17704775b4bbeea9561fb340968", null ],
    [ "data", "structlws__process__html__state.html#af21119890fdfebe28fb5c4dabfc1bdf5", null ],
    [ "pos", "structlws__process__html__state.html#a53234f2948812c7208a256f9f5b23c20", null ],
    [ "replace", "structlws__process__html__state.html#a693d2fb45378afee5da29b539c1ea644", null ],
    [ "start", "structlws__process__html__state.html#af0732884ef891e24fe5fa237ebaa21a3", null ],
    [ "swallow", "structlws__process__html__state.html#a71982bc1cbd8cf876ca0f545144404eb", null ],
    [ "vars", "structlws__process__html__state.html#a3b113e00c03a2fded51b1c85ff5bf077", null ]
];