var structpollfd =
[
    [ "events", "structpollfd.html#ac9b2f2c5b1f9a7487eb57e67cd4960ef", null ],
    [ "fd", "structpollfd.html#af084f089bdece61d177f85782d6673d0", null ],
    [ "revents", "structpollfd.html#aafb457d11cac415faf0e1e2b825118c2", null ]
];