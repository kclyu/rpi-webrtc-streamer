var group__html_chunked_substitution =
[
    [ "lws_process_html_args", "structlws__process__html__args.html", [
      [ "final", "structlws__process__html__args.html#a362547891ee0d693f3900a1f807ea475", null ],
      [ "len", "structlws__process__html__args.html#a754513f2311241cabb0cd1c90d7307ef", null ],
      [ "max_len", "structlws__process__html__args.html#a8be7fd396a1942ea2449a2fda990ff99", null ],
      [ "p", "structlws__process__html__args.html#a11859d8bedd379fbf64543b25c65fe14", null ]
    ] ],
    [ "lws_process_html_state", "structlws__process__html__state.html", [
      [ "count_vars", "structlws__process__html__state.html#adcafd17704775b4bbeea9561fb340968", null ],
      [ "data", "structlws__process__html__state.html#af21119890fdfebe28fb5c4dabfc1bdf5", null ],
      [ "pos", "structlws__process__html__state.html#a53234f2948812c7208a256f9f5b23c20", null ],
      [ "replace", "structlws__process__html__state.html#a693d2fb45378afee5da29b539c1ea644", null ],
      [ "start", "structlws__process__html__state.html#af0732884ef891e24fe5fa237ebaa21a3", null ],
      [ "swallow", "structlws__process__html__state.html#a71982bc1cbd8cf876ca0f545144404eb", null ],
      [ "vars", "structlws__process__html__state.html#a3b113e00c03a2fded51b1c85ff5bf077", null ]
    ] ],
    [ "lws_chunked_html_process", "group__html-chunked-substitution.html#ga643073f918c0a7016b690aae9793fd60", null ]
];