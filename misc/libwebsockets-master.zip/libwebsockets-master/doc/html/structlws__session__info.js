var structlws__session__info =
[
    [ "email", "structlws__session__info.html#a94b813cfc6b0da4b182659de30038ad3", null ],
    [ "ip", "structlws__session__info.html#a53eed02325e8717a53297391e3e98fac", null ],
    [ "mask", "structlws__session__info.html#afb924864b70f40372920688a5c1c895e", null ],
    [ "session", "structlws__session__info.html#a4353b5dd19400b2b15edfd7cee1e4cd5", null ],
    [ "username", "structlws__session__info.html#a3d57a70b6e7181d95a8bec429b1a7697", null ]
];