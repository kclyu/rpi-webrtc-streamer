var structlws__polarssl__context =
[
    [ "ca", "structlws__polarssl__context.html#a1872f2ea24878d807ae20ca8513674af", null ],
    [ "certificate", "structlws__polarssl__context.html#ae7e11c9129ff71c7ee71b3b2e320ff27", null ],
    [ "key", "structlws__polarssl__context.html#a919c33af37aab170f828d954de1fa270", null ]
];