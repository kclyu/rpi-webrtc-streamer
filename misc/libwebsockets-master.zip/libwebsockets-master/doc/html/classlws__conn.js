var classlws__conn =
[
    [ "lws_conn", "classlws__conn.html#af0e213af91d53d1e1aef70ed7816191f", null ],
    [ "actual_onRX", "classlws__conn.html#aef530971372f55e862f2e09bc98f1029", null ],
    [ "onDisconnect", "classlws__conn.html#a49f87612c6a3098cd1587f8382b8c85b", null ],
    [ "onError", "classlws__conn.html#a4fb477fad697ce1faf8ec7a884ea6c6b", null ],
    [ "onRX", "classlws__conn.html#aba42bdd763a36c3a331b62410969b6ba", null ],
    [ "onSent", "classlws__conn.html#aad7d2406618e560114650a91c729a596", null ],
    [ "serialized_writeable", "classlws__conn.html#accc57581269c554291dac840ed135231", null ],
    [ "set_wsi", "classlws__conn.html#afe73e53da2070f659ad6e7fd14878c7e", null ],
    [ "awaiting_on_writeable", "classlws__conn.html#a5226010afdf5421f279454e5cbb282a4", null ],
    [ "ts", "classlws__conn.html#a5cad031b6b779da42b37f4007cae541b", null ],
    [ "writeable", "classlws__conn.html#a8e1fdd467b7f66fc438dc70ae979b938", null ],
    [ "wsi", "classlws__conn.html#a7e504bd449ffb51c7ab1d2126613ebc3", null ]
];