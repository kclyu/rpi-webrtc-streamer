var group__wsstatus =
[
    [ "lws_frame_is_binary", "group__wsstatus.html#gaccd9c59336efad8af0554f79cc5966fd", null ],
    [ "lws_get_reserved_bits", "group__wsstatus.html#ga3df5045656dfb6b0e63a38de2dca79d2", null ],
    [ "lws_is_cgi", "group__wsstatus.html#ga4ad226d5e01024b4046f4a5a37199aa1", null ],
    [ "lws_is_final_fragment", "group__wsstatus.html#ga08e9ee165fca503fd9427d55cfecac37", null ],
    [ "lws_is_ssl", "group__wsstatus.html#ga26a140623d202dd2bf2004deb6994baa", null ],
    [ "lws_partial_buffered", "group__wsstatus.html#gaeca4afc94b1f026034f99cbba37e2f85", null ],
    [ "lws_send_pipe_choked", "group__wsstatus.html#ga2bb3655329b4651cd06f79ee3a764421", null ]
];