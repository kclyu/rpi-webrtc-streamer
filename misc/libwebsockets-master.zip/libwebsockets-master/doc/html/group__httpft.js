var group__httpft =
[
    [ "lws_get_mimetype", "group__httpft.html#gab4da87a4800413f15e7aba649fb1d77c", null ],
    [ "lws_serve_http_file", "group__httpft.html#gab393a06d3d2722af4c3f8b06842c80d7", null ]
];